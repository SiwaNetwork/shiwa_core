#!/usr/bin/env python3
"""
Скрипт для гибридных атак на Bitcoin кошелек
"""

import subprocess
import sys
import time

def run_hybrid_attacks(hash_file):
    """Запуск серии гибридных атак"""
    
    attacks = [
        # Словарь + цифры в конце
        {
            'name': 'Словарь + 1-4 цифры в конце',
            'cmd': ['hashcat', '-m', '11300', '-a', '6', hash_file, 'common_passwords.txt', '?d', '--force'],
            'time': 1800
        },
        {
            'name': 'Словарь + 2 цифры в конце', 
            'cmd': ['hashcat', '-m', '11300', '-a', '6', hash_file, 'common_passwords.txt', '?d?d', '--force'],
            'time': 1800
        },
        {
            'name': 'Словарь + 3 цифры в конце',
            'cmd': ['hashcat', '-m', '11300', '-a', '6', hash_file, 'common_passwords.txt', '?d?d?d', '--force'],
            'time': 3600
        },
        
        # Цифры в начале + словарь
        {
            'name': '2 цифры + словарь',
            'cmd': ['hashcat', '-m', '11300', '-a', '7', hash_file, '?d?d', 'common_passwords.txt', '--force'],
            'time': 1800
        },
        {
            'name': '4 цифры + словарь',
            'cmd': ['hashcat', '-m', '11300', '-a', '7', hash_file, '?d?d?d?d', 'common_passwords.txt', '--force'],
            'time': 3600
        },
        
        # Комбинированные атаки
        {
            'name': 'Комбинация двух словарей',
            'cmd': ['hashcat', '-m', '11300', '-a', '1', hash_file, 'words1.txt', 'words2.txt', '--force'],
            'time': 3600
        }
    ]
    
    for i, attack in enumerate(attacks):
        print(f"\n🎯 Атака {i+1}/{len(attacks)}: {attack['name']}")
        print(f"⏱️ Максимальное время: {attack['time']} секунд")
        
        try:
            # Добавляем ограничение времени
            cmd = attack['cmd'] + ['--runtime', str(attack['time'])]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=attack['time']+60)
            
            if 'Cracked' in result.stdout or result.returncode == 0:
                print("✅ Возможно найден результат!")
                print(result.stdout)
                return True
            else:
                print("⏭️ Переход к следующей атаке")
                
        except subprocess.TimeoutExpired:
            print("⏰ Время атаки истекло")
        except Exception as e:
            print(f"❌ Ошибка: {e}")
    
    return False

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Использование: python3 hybrid_attacks.py <hash_file>")
        sys.exit(1)
    
    hash_file = sys.argv[1]
    success = run_hybrid_attacks(hash_file)
    
    if success:
        print("\n🎉 Атака успешна!")
    else:
        print("\n😞 Все атаки завершены без результата")
