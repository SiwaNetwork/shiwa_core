#!/usr/bin/env python3
import re
import json
from collections import defaultdict

def extract_passwords_from_text(text):
    """Извлекает потенциальные пароли из текста"""
    passwords = []
    
    # Паттерны для поиска паролей
    password_patterns = [
        r'pass\w*\s*[:=]\s*([^\s\n]+)',
        r'password\s*[:=]\s*([^\s\n]+)',
        r'пароль\s*[:=]\s*([^\s\n]+)',
        r'-password-\s*([^\s\n]+)',
        r'main wallet password\s*([^\s\n]+)',
        r'login password\s*([^\s\n]+)',
        r'trading password\s*([^\s\n]+)',
    ]
    
    for pattern in password_patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        passwords.extend(matches)
    
    return passwords

def extract_specific_passwords(text):
    """Извлекает конкретные пароли из текста"""
    specific_passwords = []
    
    lines = text.split('\n')
    for line in lines:
        line = line.strip()
        
        # Ищем строки с паролями
        if any(keyword in line.lower() for keyword in ['pass', 'password', 'пароль']):
            # Извлекаем текст после двоеточия или равно
            if ':' in line:
                password_part = line.split(':', 1)[1].strip()
                if password_part and not password_part.startswith('http'):
                    specific_passwords.append(password_part)
            elif '=' in line:
                password_part = line.split('=', 1)[1].strip()
                if password_part and not password_part.startswith('http'):
                    specific_passwords.append(password_part)
    
    return specific_passwords

def extract_patterns_and_keywords(text):
    """Извлекает паттерны и ключевые слова для генерации паролей"""
    patterns = {
        'names': [],
        'numbers': [],
        'dates': [],
        'special_chars': [],
        'common_words': []
    }
    
    # Имена
    names = re.findall(r'\b(Michele|Barbara|Viki|Valle|Super7Michele)\b', text, re.IGNORECASE)
    patterns['names'].extend(set(names))
    
    # Числа
    numbers = re.findall(r'\b(\d{4,8})\b', text)
    patterns['numbers'].extend(set(numbers))
    
    # Даты
    dates = re.findall(r'\b(\d{1,2}[./]\d{1,2}[./]\d{2,4})\b', text)
    patterns['dates'].extend(set(dates))
    
    # Общие слова
    common_words = ['Super', 'Michele', 'Barbara', 'wallet', 'bitcoin', 'crypto', 'ledger']
    for word in common_words:
        if word.lower() in text.lower():
            patterns['common_words'].append(word)
    
    return patterns

def analyze_password_structure(passwords):
    """Анализирует структуру паролей"""
    analysis = {
        'length_distribution': defaultdict(int),
        'character_patterns': defaultdict(int),
        'common_prefixes': defaultdict(int),
        'common_suffixes': defaultdict(int),
        'special_chars_used': set()
    }
    
    for password in passwords:
        # Длина
        analysis['length_distribution'][len(password)] += 1
        
        # Паттерны символов
        has_upper = any(c.isupper() for c in password)
        has_lower = any(c.islower() for c in password)
        has_digit = any(c.isdigit() for c in password)
        has_special = any(not c.isalnum() for c in password)
        
        pattern = ''
        if has_upper: pattern += 'U'
        if has_lower: pattern += 'L'
        if has_digit: pattern += 'D'
        if has_special: pattern += 'S'
        
        analysis['character_patterns'][pattern] += 1
        
        # Префиксы и суффиксы
        if len(password) >= 3:
            analysis['common_prefixes'][password[:3]] += 1
            analysis['common_suffixes'][password[-3:]] += 1
        
        # Специальные символы
        for char in password:
            if not char.isalnum():
                analysis['special_chars_used'].add(char)
    
    return analysis

def main():
    # Читаем извлеченный текст
    with open('/home/ubuntu/extracted_docx_content.txt', 'r', encoding='utf-8') as f:
        docx_content = f.read()
    
    print("=== АНАЛИЗ ПАРОЛЕЙ ИЗ ФАЙЛОВ ===\n")
    
    # Извлекаем пароли
    extracted_passwords = extract_passwords_from_text(docx_content)
    specific_passwords = extract_specific_passwords(docx_content)
    
    # Объединяем и очищаем
    all_passwords = list(set(extracted_passwords + specific_passwords))
    all_passwords = [p for p in all_passwords if len(p) > 3 and not p.startswith('http')]
    
    print("НАЙДЕННЫЕ ПАРОЛИ:")
    for i, password in enumerate(all_passwords, 1):
        print(f"{i:2d}. {password}")
    
    print(f"\nВСЕГО НАЙДЕНО: {len(all_passwords)} паролей\n")
    
    # Извлекаем паттерны
    patterns = extract_patterns_and_keywords(docx_content)
    print("НАЙДЕННЫЕ ПАТТЕРНЫ:")
    for category, items in patterns.items():
        if items:
            print(f"{category.upper()}: {', '.join(map(str, set(items)))}")
    
    # Анализируем структуру
    if all_passwords:
        analysis = analyze_password_structure(all_passwords)
        print(f"\nАНАЛИЗ СТРУКТУРЫ ПАРОЛЕЙ:")
        print(f"Распределение по длине: {dict(analysis['length_distribution'])}")
        print(f"Паттерны символов: {dict(analysis['character_patterns'])}")
        print(f"Используемые спец. символы: {''.join(sorted(analysis['special_chars_used']))}")
    
    # Сохраняем результаты
    results = {
        'passwords': all_passwords,
        'patterns': patterns,
        'analysis': {k: dict(v) if isinstance(v, defaultdict) else list(v) if isinstance(v, set) else v 
                    for k, v in analysis.items()} if all_passwords else {}
    }
    
    with open('/home/ubuntu/password_analysis_results.json', 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    print(f"\nРезультаты сохранены в password_analysis_results.json")

if __name__ == "__main__":
    main()

