#!/usr/bin/env python3
"""
Генератор пользовательских масок для hashcat
"""

def generate_common_masks():
    """Генерация часто используемых масок паролей"""
    
    masks = []
    
    # Пароли с заглавной буквы + строчные + цифры
    for length in range(6, 11):
        mask = '?u' + '?l' * (length - 2) + '?d'
        masks.append({
            'mask': mask,
            'description': f'Заглавная + {length-2} строчных + цифра (длина {length})',
            'keyspace': 26 * (26 ** (length - 2)) * 10
        })
    
    # Пароли из букв и цифр
    for length in range(4, 9):
        mask = '?1' * length
        custom_charset = '?l?u?d'
        masks.append({
            'mask': mask,
            'custom_charset': custom_charset,
            'description': f'Буквы + цифры (длина {length})',
            'keyspace': 62 ** length
        })
    
    # Пароли с известным префиксом
    common_prefixes = ['pass', 'user', 'admin', 'test', 'demo']
    for prefix in common_prefixes:
        for suffix_len in range(2, 6):
            mask = f'"{prefix}"' + '?d' * suffix_len
            masks.append({
                'mask': mask,
                'description': f'"{prefix}" + {suffix_len} цифр',
                'keyspace': 10 ** suffix_len
            })
    
    return masks

def save_masks_to_file(masks, filename='custom_masks.txt'):
    """Сохранение масок в файл"""
    
    with open(filename, 'w') as f:
        f.write("# Пользовательские маски для hashcat\n")
        f.write("# Формат: маска | описание | размер пространства ключей\n\n")
        
        for mask in masks:
            keyspace_str = f"{mask['keyspace']:,}"
            f.write(f"{mask['mask']} | {mask['description']} | {keyspace_str}\n")
            
            # Добавляем команду hashcat
            if 'custom_charset' in mask:
                cmd = f"hashcat -m 11300 -a 3 bitcoin_hash.txt {mask['mask']} -1 {mask['custom_charset']} --force"
            else:
                cmd = f"hashcat -m 11300 -a 3 bitcoin_hash.txt {mask['mask']} --force"
            f.write(f"# Команда: {cmd}\n\n")

def create_mask_attack_script(masks, output_file='mask_attacks.bat'):
    """Создание batch скрипта для выполнения атак по маскам"""
    
    with open(output_file, 'w') as f:
        f.write("@echo off\n")
        f.write("echo ========================================\n")
        f.write("echo     Атаки по пользовательским маскам\n")
        f.write("echo ========================================\n\n")
        
        for i, mask in enumerate(masks[:10]):  # Ограничиваем первыми 10 масками
            f.write(f"echo Атака {i+1}: {mask['description']}\n")
            
            if 'custom_charset' in mask:
                cmd = f"hashcat -m 11300 -a 3 bitcoin_hash.txt {mask['mask']} -1 {mask['custom_charset']} --runtime=1800 --force"
            else:
                cmd = f"hashcat -m 11300 -a 3 bitcoin_hash.txt {mask['mask']} --runtime=1800 --force"
            
            f.write(f"{cmd}\n")
            f.write("if %ERRORLEVEL% EQU 0 goto found\n\n")
        
        f.write(":found\n")
        f.write("echo Пароль найден!\n")
        f.write("pause\n")

if __name__ == "__main__":
    print("🎭 Генерация пользовательских масок...")
    
    masks = generate_common_masks()
    save_masks_to_file(masks)
    create_mask_attack_script(masks)
    
    print(f"✅ Создано {len(masks)} масок")
    print("📄 Файлы созданы:")
    print("   - custom_masks.txt (список масок)")
    print("   - mask_attacks.bat (скрипт для выполнения)")
