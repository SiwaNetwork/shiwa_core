#!/usr/bin/env python3
"""
Калькулятор времени восстановления паролей Bitcoin кошелька
Версия: 1.0
Автор: Manus AI
"""

import math
import argparse

class PasswordTimeCalculator:
    def __init__(self):
        # Размеры алфавитов
        self.charsets = {
            'digits': {'size': 10, 'chars': '0123456789'},
            'lowercase': {'size': 26, 'chars': 'abcdefghijklmnopqrstuvwxyz'},
            'uppercase': {'size': 26, 'chars': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'},
            'letters': {'size': 52, 'chars': 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'},
            'alphanumeric': {'size': 62, 'chars': 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'},
            'special': {'size': 32, 'chars': '!@#$%^&*()_+-=[]{}|;:,.<>?'},
            'ascii_printable': {'size': 95, 'chars': 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{}|;:,.<>?'}
        }
        
        # Типичные скорости для Bitcoin хешей (H/s)
        self.gpu_speeds = {
            'GTX 1060': 15000,
            'GTX 1070': 20000,
            'GTX 1080': 25000,
            'GTX 1080 Ti': 30000,
            'RTX 2060': 25000,
            'RTX 2070': 30000,
            'RTX 2080': 35000,
            'RTX 2080 Ti': 40000,
            'RTX 3060': 35000,
            'RTX 3070': 45000,
            'RTX 3080': 50000,
            'RTX 3090': 55000,
            'RTX 4060': 40000,
            'RTX 4070': 50000,
            'RTX 4080': 70000,
            'RTX 4090': 80000,
            'RX 580': 12000,
            'RX 6700 XT': 35000,
            'RX 6800 XT': 40000,
            'RX 6900 XT': 45000,
            'RX 7700 XT': 50000,
            'RX 7800 XT': 55000,
            'RX 7900 XTX': 60000
        }
    
    def calculate_keyspace(self, charset_name, length):
        """Расчет размера пространства ключей"""
        if charset_name not in self.charsets:
            raise ValueError(f"Неизвестный набор символов: {charset_name}")
        
        charset_size = self.charsets[charset_name]['size']
        return charset_size ** length
    
    def format_time(self, seconds):
        """Форматирование времени в читаемый вид"""
        if seconds < 1:
            return f"{seconds:.3f} секунд"
        elif seconds < 60:
            return f"{seconds:.1f} секунд"
        elif seconds < 3600:
            minutes = seconds / 60
            return f"{minutes:.1f} минут"
        elif seconds < 86400:
            hours = seconds / 3600
            return f"{hours:.1f} часов"
        elif seconds < 31536000:
            days = seconds / 86400
            return f"{days:.1f} дней"
        else:
            years = seconds / 31536000
            return f"{years:.1f} лет"
    
    def format_number(self, number):
        """Форматирование больших чисел"""
        if number < 1000:
            return str(int(number))
        elif number < 1000000:
            return f"{number/1000:.1f}K"
        elif number < 1000000000:
            return f"{number/1000000:.1f}M"
        elif number < 1000000000000:
            return f"{number/1000000000:.1f}B"
        else:
            return f"{number/1000000000000:.1f}T"
    
    def calculate_recovery_time(self, charset_name, length, speed_hps):
        """Расчет времени восстановления"""
        keyspace = self.calculate_keyspace(charset_name, length)
        
        # Среднее время (найдем пароль в среднем за половину времени)
        avg_time = keyspace / (2 * speed_hps)
        # Максимальное время (худший случай)
        max_time = keyspace / speed_hps
        
        return {
            'keyspace': keyspace,
            'average_seconds': avg_time,
            'maximum_seconds': max_time,
            'average_formatted': self.format_time(avg_time),
            'maximum_formatted': self.format_time(max_time),
            'keyspace_formatted': self.format_number(keyspace)
        }
    
    def generate_report(self, max_length=10):
        """Генерация полного отчета по времени восстановления"""
        print("=" * 80)
        print("КАЛЬКУЛЯТОР ВРЕМЕНИ ВОССТАНОВЛЕНИЯ ПАРОЛЕЙ BITCOIN КОШЕЛЬКА")
        print("=" * 80)
        print()
        
        # Выбираем среднюю скорость для расчетов
        avg_speed = 50000  # RTX 3080 как референс
        
        print(f"Расчеты основаны на скорости: {avg_speed:,} H/s (RTX 3080)")
        print("Время указано для СРЕДНЕГО случая (пароль найден за 50% времени)")
        print()
        
        for charset_name in ['digits', 'lowercase', 'alphanumeric', 'ascii_printable']:
            print(f"📊 НАБОР СИМВОЛОВ: {charset_name.upper()}")
            print(f"   Размер алфавита: {self.charsets[charset_name]['size']} символов")
            print(f"   Символы: {self.charsets[charset_name]['chars'][:50]}...")
            print()
            
            print("   Длина | Комбинаций | Среднее время")
            print("   ------|------------|---------------")
            
            for length in range(1, max_length + 1):
                result = self.calculate_recovery_time(charset_name, length, avg_speed)
                
                print(f"   {length:5d} | {result['keyspace_formatted']:>10s} | {result['average_formatted']}")
            
            print()
    
    def compare_gpus(self, charset_name, length):
        """Сравнение времени восстановления для разных GPU"""
        print(f"🎮 СРАВНЕНИЕ GPU ДЛЯ ПАРОЛЯ: {charset_name} длиной {length}")
        print("=" * 60)
        
        keyspace = self.calculate_keyspace(charset_name, length)
        print(f"Размер пространства ключей: {self.format_number(keyspace)}")
        print()
        
        print("GPU модель        | Скорость  | Среднее время")
        print("------------------|-----------|---------------")
        
        for gpu_name, speed in sorted(self.gpu_speeds.items(), key=lambda x: x[1], reverse=True):
            result = self.calculate_recovery_time(charset_name, length, speed)
            print(f"{gpu_name:<17s} | {speed:>7,} H/s | {result['average_formatted']}")
    
    def interactive_calculator(self):
        """Интерактивный калькулятор"""
        print("🧮 ИНТЕРАКТИВНЫЙ КАЛЬКУЛЯТОР")
        print("=" * 40)
        
        while True:
            print("\nДоступные наборы символов:")
            for i, charset_name in enumerate(self.charsets.keys(), 1):
                print(f"{i}. {charset_name} ({self.charsets[charset_name]['size']} символов)")
            
            try:
                choice = int(input("\nВыберите набор символов (номер): ")) - 1
                charset_names = list(self.charsets.keys())
                
                if 0 <= choice < len(charset_names):
                    charset_name = charset_names[choice]
                else:
                    print("❌ Неверный выбор!")
                    continue
                
                length = int(input("Введите длину пароля: "))
                if length <= 0:
                    print("❌ Длина должна быть положительным числом!")
                    continue
                
                speed = int(input("Введите скорость в H/s (или 0 для автовыбора): "))
                if speed <= 0:
                    speed = 50000  # Значение по умолчанию
                
                result = self.calculate_recovery_time(charset_name, length, speed)
                
                print(f"\n📊 РЕЗУЛЬТАТЫ:")
                print(f"Набор символов: {charset_name}")
                print(f"Длина пароля: {length}")
                print(f"Размер пространства: {result['keyspace_formatted']}")
                print(f"Скорость: {speed:,} H/s")
                print(f"Среднее время: {result['average_formatted']}")
                print(f"Максимальное время: {result['maximum_formatted']}")
                
                # Оценка практичности
                if result['average_seconds'] < 3600:
                    print("✅ Восстановление ПРАКТИЧНО (менее часа)")
                elif result['average_seconds'] < 86400:
                    print("⚠️ Восстановление ВОЗМОЖНО (менее суток)")
                elif result['average_seconds'] < 31536000:
                    print("🔶 Восстановление СЛОЖНО (менее года)")
                else:
                    print("❌ Восстановление НЕПРАКТИЧНО (более года)")
                
                if input("\nПродолжить? (y/n): ").lower() != 'y':
                    break
                    
            except ValueError:
                print("❌ Введите корректное число!")
            except KeyboardInterrupt:
                print("\n👋 До свидания!")
                break

def main():
    parser = argparse.ArgumentParser(description='Калькулятор времени восстановления паролей Bitcoin')
    parser.add_argument('--report', action='store_true', help='Генерация полного отчета')
    parser.add_argument('--compare', nargs=2, metavar=('CHARSET', 'LENGTH'), 
                       help='Сравнение GPU для заданного пароля')
    parser.add_argument('--interactive', action='store_true', help='Интерактивный режим')
    
    args = parser.parse_args()
    
    calculator = PasswordTimeCalculator()
    
    if args.report:
        calculator.generate_report()
    elif args.compare:
        charset_name, length = args.compare
        try:
            length = int(length)
            calculator.compare_gpus(charset_name, length)
        except ValueError:
            print("❌ Длина должна быть числом!")
    elif args.interactive:
        calculator.interactive_calculator()
    else:
        # По умолчанию показываем краткий отчет
        calculator.generate_report(8)

if __name__ == "__main__":
    main()

