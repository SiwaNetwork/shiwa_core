@echo off
echo ========================================
echo   Быстрое тестирование коротких паролей
echo ========================================
echo.

REM Проверка наличия файлов
if not exist "bitcoin_hash.txt" (
    echo ОШИБКА: Файл bitcoin_hash.txt не найден!
    pause
    exit /b 1
)

if not exist "hashcat.exe" (
    echo ОШИБКА: hashcat.exe не найден!
    pause
    exit /b 1
)

echo Тестирование 4-значных цифровых паролей...
hashcat -m 11300 -a 3 bitcoin_hash.txt ?d?d?d?d --runtime=300 --session quick_digits --force

echo.
echo Тестирование 5-значных цифровых паролей...
hashcat -m 11300 -a 3 bitcoin_hash.txt ?d?d?d?d?d --runtime=600 --session quick_digits5 --force

echo.
echo Тестирование 4-символьных буквенных паролей...
hashcat -m 11300 -a 3 bitcoin_hash.txt ?l?l?l?l --runtime=600 --session quick_letters --force

echo.
echo Быстрое тестирование завершено!
pause
