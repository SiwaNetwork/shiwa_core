@echo off
echo ========================================
echo     Полный брутфорс Bitcoin кошелька
echo ========================================
echo.
echo ВНИМАНИЕ: Этот процесс может занять очень много времени!
echo Рекомендуется запускать только для коротких паролей.
echo.
pause

REM Проверка наличия файлов
if not exist "bitcoin_hash.txt" (
    echo ОШИБКА: Файл bitcoin_hash.txt не найден!
    pause
    exit /b 1
)

echo Запуск инкрементального брутфорса...
echo Начинаем с 4 символов, максимум 8 символов
echo Набор символов: буквы + цифры

hashcat -m 11300 -a 3 bitcoin_hash.txt ?1?1?1?1 --increment --increment-min=4 --increment-max=8 -1 ?l?u?d -w 3 -O --session full_bruteforce --force

echo.
echo Брутфорс завершен!
pause
