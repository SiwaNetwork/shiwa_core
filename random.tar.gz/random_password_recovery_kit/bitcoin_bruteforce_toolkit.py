#!/usr/bin/env python3
"""
Автоматизированный инструмент для восстановления случайных паролей Bitcoin кошелька
Версия: 2.0
Автор: Manus AI

Этот скрипт автоматизирует процесс восстановления паролей с использованием различных
стратегий атак, включая брутфорс, гибридные атаки и оптимизированные подходы.
"""

import os
import sys
import time
import subprocess
import json
import argparse
from datetime import datetime, timedelta
import threading
import queue

class BitcoinPasswordRecovery:
    def __init__(self, hash_file, hashcat_path="hashcat"):
        self.hash_file = hash_file
        self.hashcat_path = hashcat_path
        self.session_name = f"bitcoin_recovery_{int(time.time())}"
        self.results_queue = queue.Queue()
        self.stop_event = threading.Event()
        
    def check_hashcat_installation(self):
        """Проверка установки и работоспособности hashcat"""
        try:
            result = subprocess.run([self.hashcat_path, "--version"], 
                                  capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                print(f"✓ Hashcat найден: {result.stdout.strip()}")
                return True
            else:
                print("✗ Ошибка при запуске hashcat")
                return False
        except FileNotFoundError:
            print("✗ Hashcat не найден в системе")
            return False
        except subprocess.TimeoutExpired:
            print("✗ Timeout при проверке hashcat")
            return False
    
    def benchmark_system(self):
        """Тестирование производительности системы"""
        print("🔧 Запуск бенчмарка системы...")
        try:
            cmd = [self.hashcat_path, "-b", "-m", "11300"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                # Извлечение скорости из вывода бенчмарка
                lines = result.stdout.split('\n')
                for line in lines:
                    if "11300" in line and "H/s" in line:
                        speed_info = line.split()
                        for i, part in enumerate(speed_info):
                            if "H/s" in part and i > 0:
                                speed = speed_info[i-1]
                                print(f"📊 Производительность Bitcoin хешей: {speed} H/s")
                                return self.parse_speed(speed)
                
                print("⚠️ Не удалось определить скорость из бенчмарка")
                return 50000  # Значение по умолчанию
            else:
                print("⚠️ Ошибка при выполнении бенчмарка")
                return 50000
                
        except subprocess.TimeoutExpired:
            print("⚠️ Timeout при выполнении бенчмарка")
            return 50000
    
    def parse_speed(self, speed_str):
        """Парсинг строки скорости в числовое значение"""
        try:
            # Удаление запятых и преобразование в число
            speed_str = speed_str.replace(',', '').replace('.', '')
            if 'k' in speed_str.lower():
                return int(float(speed_str.replace('k', '').replace('K', '')) * 1000)
            elif 'm' in speed_str.lower():
                return int(float(speed_str.replace('m', '').replace('M', '')) * 1000000)
            else:
                return int(speed_str)
        except:
            return 50000
    
    def estimate_time(self, keyspace_size, speed):
        """Оценка времени восстановления"""
        avg_time = keyspace_size / (2 * speed)  # В среднем найдем за половину времени
        max_time = keyspace_size / speed  # Максимальное время
        
        return {
            'average_seconds': avg_time,
            'maximum_seconds': max_time,
            'average_formatted': self.format_time(avg_time),
            'maximum_formatted': self.format_time(max_time)
        }
    
    def format_time(self, seconds):
        """Форматирование времени в читаемый вид"""
        if seconds < 60:
            return f"{seconds:.1f} секунд"
        elif seconds < 3600:
            return f"{seconds/60:.1f} минут"
        elif seconds < 86400:
            return f"{seconds/3600:.1f} часов"
        elif seconds < 31536000:
            return f"{seconds/86400:.1f} дней"
        else:
            return f"{seconds/31536000:.1f} лет"
    
    def calculate_keyspace(self, charset_size, length):
        """Расчет размера пространства ключей"""
        return charset_size ** length
    
    def run_attack(self, attack_type, params, time_limit=None):
        """Запуск атаки с заданными параметрами"""
        cmd = [self.hashcat_path, "-m", "11300", "-a", str(attack_type)]
        cmd.extend(params)
        cmd.extend(["--session", self.session_name, "--force"])
        
        if time_limit:
            cmd.extend(["--runtime", str(time_limit)])
        
        print(f"🚀 Запуск команды: {' '.join(cmd)}")
        
        try:
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, 
                                     stderr=subprocess.PIPE, text=True)
            
            # Мониторинг процесса
            while process.poll() is None:
                if self.stop_event.is_set():
                    process.terminate()
                    break
                time.sleep(1)
            
            stdout, stderr = process.communicate()
            
            if process.returncode == 0:
                # Проверка на найденный пароль
                if self.check_for_cracked_password():
                    return True, "Пароль найден!"
                else:
                    return False, "Атака завершена без результата"
            else:
                return False, f"Ошибка: {stderr}"
                
        except Exception as e:
            return False, f"Исключение: {str(e)}"
    
    def check_for_cracked_password(self):
        """Проверка файла potfile на наличие найденного пароля"""
        potfile_path = f"{self.hashcat_path}.potfile"
        if os.path.exists(potfile_path):
            try:
                with open(potfile_path, 'r') as f:
                    content = f.read()
                    if self.hash_file in content:
                        return True
            except:
                pass
        return False
    
    def incremental_bruteforce(self, charset, min_length=4, max_length=8, time_per_length=3600):
        """Инкрементальная брутфорс атака"""
        print(f"🔄 Запуск инкрементальной атаки (длина {min_length}-{max_length})")
        
        charset_map = {
            'lowercase': '?l',
            'uppercase': '?u', 
            'digits': '?d',
            'special': '?s',
            'all': '?a',
            'alnum': '?l?u?d'
        }
        
        mask_char = charset_map.get(charset, '?a')
        
        for length in range(min_length, max_length + 1):
            if self.stop_event.is_set():
                break
                
            mask = mask_char * length
            keyspace = self.calculate_keyspace(
                {'lowercase': 26, 'uppercase': 26, 'digits': 10, 
                 'special': 32, 'all': 95, 'alnum': 62}.get(charset, 95), 
                length
            )
            
            print(f"📏 Длина {length}: {keyspace:,} комбинаций")
            
            params = [self.hash_file, mask]
            success, message = self.run_attack(3, params, time_per_length)
            
            if success:
                print(f"✅ {message}")
                return True
            
            print(f"⏭️ Переход к длине {length + 1}")
        
        return False
    
    def smart_bruteforce(self, speed):
        """Умная брутфорс атака с оптимизированной последовательностью"""
        print("🧠 Запуск умной брутфорс атаки...")
        
        # Стратегии в порядке вероятности успеха
        strategies = [
            # Короткие пароли только из цифр
            {'charset': 'digits', 'length': 4, 'time': 60},
            {'charset': 'digits', 'length': 5, 'time': 300},
            {'charset': 'digits', 'length': 6, 'time': 1800},
            
            # Короткие пароли из букв
            {'charset': 'lowercase', 'length': 4, 'time': 300},
            {'charset': 'lowercase', 'length': 5, 'time': 1800},
            
            # Смешанные короткие пароли
            {'charset': 'alnum', 'length': 4, 'time': 600},
            {'charset': 'alnum', 'length': 5, 'time': 3600},
            {'charset': 'alnum', 'length': 6, 'time': 7200},
            
            # Более длинные пароли (только если есть время)
            {'charset': 'lowercase', 'length': 6, 'time': 7200},
            {'charset': 'lowercase', 'length': 7, 'time': 14400},
        ]
        
        for i, strategy in enumerate(strategies):
            if self.stop_event.is_set():
                break
                
            print(f"\n📋 Стратегия {i+1}/{len(strategies)}: "
                  f"{strategy['charset']} длина {strategy['length']}")
            
            # Оценка времени
            charset_sizes = {
                'digits': 10, 'lowercase': 26, 'uppercase': 26,
                'alnum': 62, 'all': 95
            }
            keyspace = self.calculate_keyspace(
                charset_sizes[strategy['charset']], 
                strategy['length']
            )
            
            time_est = self.estimate_time(keyspace, speed)
            print(f"⏱️ Оценка времени: {time_est['average_formatted']} "
                  f"(макс: {time_est['maximum_formatted']})")
            
            if time_est['maximum_seconds'] > strategy['time'] * 2:
                print(f"⏭️ Пропуск - слишком долго для текущей стратегии")
                continue
            
            # Запуск атаки
            charset_map = {
                'digits': '?d', 'lowercase': '?l', 'uppercase': '?u',
                'alnum': '?1', 'all': '?a'
            }
            
            if strategy['charset'] == 'alnum':
                mask = '?1' * strategy['length']
                params = [self.hash_file, mask, '-1', '?l?u?d']
            else:
                mask = charset_map[strategy['charset']] * strategy['length']
                params = [self.hash_file, mask]
            
            success, message = self.run_attack(3, params, strategy['time'])
            
            if success:
                print(f"✅ {message}")
                return True
        
        return False

def create_batch_scripts():
    """Создание batch скриптов для Windows"""
    
    # Скрипт для быстрого тестирования коротких паролей
    quick_test_script = '''@echo off
echo ========================================
echo   Быстрое тестирование коротких паролей
echo ========================================
echo.

REM Проверка наличия файлов
if not exist "bitcoin_hash.txt" (
    echo ОШИБКА: Файл bitcoin_hash.txt не найден!
    pause
    exit /b 1
)

if not exist "hashcat.exe" (
    echo ОШИБКА: hashcat.exe не найден!
    pause
    exit /b 1
)

echo Тестирование 4-значных цифровых паролей...
hashcat -m 11300 -a 3 bitcoin_hash.txt ?d?d?d?d --runtime=300 --session quick_digits --force

echo.
echo Тестирование 5-значных цифровых паролей...
hashcat -m 11300 -a 3 bitcoin_hash.txt ?d?d?d?d?d --runtime=600 --session quick_digits5 --force

echo.
echo Тестирование 4-символьных буквенных паролей...
hashcat -m 11300 -a 3 bitcoin_hash.txt ?l?l?l?l --runtime=600 --session quick_letters --force

echo.
echo Быстрое тестирование завершено!
pause
'''

    # Скрипт для полного брутфорса
    full_bruteforce_script = '''@echo off
echo ========================================
echo     Полный брутфорс Bitcoin кошелька
echo ========================================
echo.
echo ВНИМАНИЕ: Этот процесс может занять очень много времени!
echo Рекомендуется запускать только для коротких паролей.
echo.
pause

REM Проверка наличия файлов
if not exist "bitcoin_hash.txt" (
    echo ОШИБКА: Файл bitcoin_hash.txt не найден!
    pause
    exit /b 1
)

echo Запуск инкрементального брутфорса...
echo Начинаем с 4 символов, максимум 8 символов
echo Набор символов: буквы + цифры

hashcat -m 11300 -a 3 bitcoin_hash.txt ?1?1?1?1 --increment --increment-min=4 --increment-max=8 -1 ?l?u?d -w 3 -O --session full_bruteforce --force

echo.
echo Брутфорс завершен!
pause
'''

    # Скрипт для мониторинга прогресса
    monitor_script = '''@echo off
echo ========================================
echo      Мониторинг прогресса hashcat
echo ========================================
echo.

:loop
cls
echo Текущее время: %date% %time%
echo.
echo Проверка активных сессий hashcat...
tasklist /FI "IMAGENAME eq hashcat.exe" 2>nul | find /I "hashcat.exe" >nul
if %ERRORLEVEL% EQU 0 (
    echo ✓ Hashcat запущен
    echo.
    echo Для получения статуса нажмите 's' в окне hashcat
    echo Для паузы нажмите 'p' в окне hashcat
    echo Для остановки нажмите Ctrl+C в окне hashcat
) else (
    echo ✗ Hashcat не запущен
)

echo.
echo Проверка файла результатов...
if exist "hashcat.potfile" (
    echo ✓ Найдены результаты в hashcat.potfile:
    type hashcat.potfile
) else (
    echo ○ Пароли пока не найдены
)

echo.
echo Обновление через 30 секунд... (Ctrl+C для выхода)
timeout /t 30 /nobreak >nul
goto loop
'''

    # Сохранение скриптов
    scripts = {
        'quick_test.bat': quick_test_script,
        'full_bruteforce.bat': full_bruteforce_script,
        'monitor.bat': monitor_script
    }
    
    for filename, content in scripts.items():
        with open(f'/home/ubuntu/{filename}', 'w', encoding='utf-8') as f:
            f.write(content)
    
    print("✅ Batch скрипты созданы:")
    for filename in scripts.keys():
        print(f"   - {filename}")

def create_advanced_attack_scripts():
    """Создание продвинутых скриптов атак"""
    
    # Скрипт для гибридных атак
    hybrid_script = '''#!/usr/bin/env python3
"""
Скрипт для гибридных атак на Bitcoin кошелек
"""

import subprocess
import sys
import time

def run_hybrid_attacks(hash_file):
    """Запуск серии гибридных атак"""
    
    attacks = [
        # Словарь + цифры в конце
        {
            'name': 'Словарь + 1-4 цифры в конце',
            'cmd': ['hashcat', '-m', '11300', '-a', '6', hash_file, 'common_passwords.txt', '?d', '--force'],
            'time': 1800
        },
        {
            'name': 'Словарь + 2 цифры в конце', 
            'cmd': ['hashcat', '-m', '11300', '-a', '6', hash_file, 'common_passwords.txt', '?d?d', '--force'],
            'time': 1800
        },
        {
            'name': 'Словарь + 3 цифры в конце',
            'cmd': ['hashcat', '-m', '11300', '-a', '6', hash_file, 'common_passwords.txt', '?d?d?d', '--force'],
            'time': 3600
        },
        
        # Цифры в начале + словарь
        {
            'name': '2 цифры + словарь',
            'cmd': ['hashcat', '-m', '11300', '-a', '7', hash_file, '?d?d', 'common_passwords.txt', '--force'],
            'time': 1800
        },
        {
            'name': '4 цифры + словарь',
            'cmd': ['hashcat', '-m', '11300', '-a', '7', hash_file, '?d?d?d?d', 'common_passwords.txt', '--force'],
            'time': 3600
        },
        
        # Комбинированные атаки
        {
            'name': 'Комбинация двух словарей',
            'cmd': ['hashcat', '-m', '11300', '-a', '1', hash_file, 'words1.txt', 'words2.txt', '--force'],
            'time': 3600
        }
    ]
    
    for i, attack in enumerate(attacks):
        print(f"\\n🎯 Атака {i+1}/{len(attacks)}: {attack['name']}")
        print(f"⏱️ Максимальное время: {attack['time']} секунд")
        
        try:
            # Добавляем ограничение времени
            cmd = attack['cmd'] + ['--runtime', str(attack['time'])]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=attack['time']+60)
            
            if 'Cracked' in result.stdout or result.returncode == 0:
                print("✅ Возможно найден результат!")
                print(result.stdout)
                return True
            else:
                print("⏭️ Переход к следующей атаке")
                
        except subprocess.TimeoutExpired:
            print("⏰ Время атаки истекло")
        except Exception as e:
            print(f"❌ Ошибка: {e}")
    
    return False

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Использование: python3 hybrid_attacks.py <hash_file>")
        sys.exit(1)
    
    hash_file = sys.argv[1]
    success = run_hybrid_attacks(hash_file)
    
    if success:
        print("\\n🎉 Атака успешна!")
    else:
        print("\\n😞 Все атаки завершены без результата")
'''

    # Скрипт для создания пользовательских масок
    mask_generator_script = '''#!/usr/bin/env python3
"""
Генератор пользовательских масок для hashcat
"""

def generate_common_masks():
    """Генерация часто используемых масок паролей"""
    
    masks = []
    
    # Пароли с заглавной буквы + строчные + цифры
    for length in range(6, 11):
        mask = '?u' + '?l' * (length - 2) + '?d'
        masks.append({
            'mask': mask,
            'description': f'Заглавная + {length-2} строчных + цифра (длина {length})',
            'keyspace': 26 * (26 ** (length - 2)) * 10
        })
    
    # Пароли из букв и цифр
    for length in range(4, 9):
        mask = '?1' * length
        custom_charset = '?l?u?d'
        masks.append({
            'mask': mask,
            'custom_charset': custom_charset,
            'description': f'Буквы + цифры (длина {length})',
            'keyspace': 62 ** length
        })
    
    # Пароли с известным префиксом
    common_prefixes = ['pass', 'user', 'admin', 'test', 'demo']
    for prefix in common_prefixes:
        for suffix_len in range(2, 6):
            mask = f'"{prefix}"' + '?d' * suffix_len
            masks.append({
                'mask': mask,
                'description': f'"{prefix}" + {suffix_len} цифр',
                'keyspace': 10 ** suffix_len
            })
    
    return masks

def save_masks_to_file(masks, filename='custom_masks.txt'):
    """Сохранение масок в файл"""
    
    with open(filename, 'w') as f:
        f.write("# Пользовательские маски для hashcat\\n")
        f.write("# Формат: маска | описание | размер пространства ключей\\n\\n")
        
        for mask in masks:
            keyspace_str = f"{mask['keyspace']:,}"
            f.write(f"{mask['mask']} | {mask['description']} | {keyspace_str}\\n")
            
            # Добавляем команду hashcat
            if 'custom_charset' in mask:
                cmd = f"hashcat -m 11300 -a 3 bitcoin_hash.txt {mask['mask']} -1 {mask['custom_charset']} --force"
            else:
                cmd = f"hashcat -m 11300 -a 3 bitcoin_hash.txt {mask['mask']} --force"
            f.write(f"# Команда: {cmd}\\n\\n")

def create_mask_attack_script(masks, output_file='mask_attacks.bat'):
    """Создание batch скрипта для выполнения атак по маскам"""
    
    with open(output_file, 'w') as f:
        f.write("@echo off\\n")
        f.write("echo ========================================\\n")
        f.write("echo     Атаки по пользовательским маскам\\n")
        f.write("echo ========================================\\n\\n")
        
        for i, mask in enumerate(masks[:10]):  # Ограничиваем первыми 10 масками
            f.write(f"echo Атака {i+1}: {mask['description']}\\n")
            
            if 'custom_charset' in mask:
                cmd = f"hashcat -m 11300 -a 3 bitcoin_hash.txt {mask['mask']} -1 {mask['custom_charset']} --runtime=1800 --force"
            else:
                cmd = f"hashcat -m 11300 -a 3 bitcoin_hash.txt {mask['mask']} --runtime=1800 --force"
            
            f.write(f"{cmd}\\n")
            f.write("if %ERRORLEVEL% EQU 0 goto found\\n\\n")
        
        f.write(":found\\n")
        f.write("echo Пароль найден!\\n")
        f.write("pause\\n")

if __name__ == "__main__":
    print("🎭 Генерация пользовательских масок...")
    
    masks = generate_common_masks()
    save_masks_to_file(masks)
    create_mask_attack_script(masks)
    
    print(f"✅ Создано {len(masks)} масок")
    print("📄 Файлы созданы:")
    print("   - custom_masks.txt (список масок)")
    print("   - mask_attacks.bat (скрипт для выполнения)")
'''

    # Сохранение скриптов
    scripts = {
        'hybrid_attacks.py': hybrid_script,
        'mask_generator.py': mask_generator_script
    }
    
    for filename, content in scripts.items():
        with open(f'/home/ubuntu/{filename}', 'w', encoding='utf-8') as f:
            f.write(content)
    
    print("✅ Продвинутые скрипты созданы:")
    for filename in scripts.keys():
        print(f"   - {filename}")

if __name__ == "__main__":
    print("🛠️ Создание инструментов для восстановления случайных паролей...")
    
    # Создание batch скриптов
    create_batch_scripts()
    
    # Создание продвинутых скриптов
    create_advanced_attack_scripts()
    
    print("\\n✅ Все инструменты созданы успешно!")

