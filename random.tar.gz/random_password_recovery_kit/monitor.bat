@echo off
echo ========================================
echo      Мониторинг прогресса hashcat
echo ========================================
echo.

:loop
cls
echo Текущее время: %date% %time%
echo.
echo Проверка активных сессий hashcat...
tasklist /FI "IMAGENAME eq hashcat.exe" 2>nul | find /I "hashcat.exe" >nul
if %ERRORLEVEL% EQU 0 (
    echo ✓ Hashcat запущен
    echo.
    echo Для получения статуса нажмите 's' в окне hashcat
    echo Для паузы нажмите 'p' в окне hashcat
    echo Для остановки нажмите Ctrl+C в окне hashcat
) else (
    echo ✗ Hashcat не запущен
)

echo.
echo Проверка файла результатов...
if exist "hashcat.potfile" (
    echo ✓ Найдены результаты в hashcat.potfile:
    type hashcat.potfile
) else (
    echo ○ Пароли пока не найдены
)

echo.
echo Обновление через 30 секунд... (Ctrl+C для выхода)
timeout /t 30 /nobreak >nul
goto loop
