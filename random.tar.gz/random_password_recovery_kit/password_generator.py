#!/usr/bin/env python3
import json
import itertools
from typing import List, Set

class PasswordVariationGenerator:
    def __init__(self):
        # Загружаем найденные пароли
        with open('/home/ubuntu/detailed_passwords.json', 'r', encoding='utf-8') as f:
            self.password_data = json.load(f)
        
        # Базовые элементы для генерации
        self.base_words = ['Michele', 'Barbara', 'Super7Michele', 'Gardnelion96', 'bitcoin', 'wallet', 'crypto', 'ledger']
        self.numbers = ['1980', '1987', '120885', '2817', '1234', '7', '71', '96']
        self.special_chars = ['@', '#', '!', '$', '+', '°', '.', '_', '-']
        self.common_suffixes = ['@#@!', '#@!', '$#@!', '1980@#@!', '71@', '#!@', '@7']
        
        # Паттерны трансформации
        self.transformations = {
            'a': '@', 'A': '@',
            'i': '!', 'I': '!', 
            'o': '0', 'O': '0',
            's': '$', 'S': '$',
            'e': '3', 'E': '3',
            'l': '1', 'L': '1'
        }
    
    def apply_leet_speak(self, password: str) -> List[str]:
        """Применяет leet speak трансформации"""
        variations = [password]
        
        # Простые замены
        for original, replacement in self.transformations.items():
            if original in password:
                new_password = password.replace(original, replacement)
                variations.append(new_password)
        
        # Комбинированные замены
        temp_password = password
        for original, replacement in self.transformations.items():
            temp_password = temp_password.replace(original, replacement)
        if temp_password != password:
            variations.append(temp_password)
        
        return list(set(variations))
    
    def generate_case_variations(self, password: str) -> List[str]:
        """Генерирует вариации с разным регистром"""
        variations = [
            password,
            password.lower(),
            password.upper(),
            password.capitalize(),
            password.swapcase()
        ]
        
        return list(set(variations))
    
    def add_common_modifications(self, base_password: str) -> List[str]:
        """Добавляет общие модификации к базовому паролю"""
        variations = []
        
        # Добавление чисел в конец
        for num in self.numbers:
            variations.append(base_password + num)
            variations.append(base_password + '_' + num)
            variations.append(base_password + '-' + num)
        
        # Добавление специальных символов
        for suffix in self.common_suffixes:
            variations.append(base_password + suffix)
        
        # Добавление отдельных символов
        for char in self.special_chars:
            variations.append(base_password + char)
            variations.append(char + base_password)
        
        return variations
    
    def generate_typo_variations(self, password: str) -> List[str]:
        """Генерирует вариации с возможными опечатками"""
        variations = []
        
        # Удаление последнего символа
        if len(password) > 1:
            variations.append(password[:-1])
        
        # Удаление первого символа
        if len(password) > 1:
            variations.append(password[1:])
        
        # Замена последнего символа
        if len(password) > 0:
            for char in self.special_chars:
                variations.append(password[:-1] + char)
        
        # Дублирование последнего символа
        if len(password) > 0:
            variations.append(password + password[-1])
        
        return variations
    
    def generate_combinations(self, elements: List[str], max_combinations: int = 2) -> List[str]:
        """Генерирует комбинации элементов"""
        combinations = []
        
        # Одиночные элементы
        combinations.extend(elements)
        
        # Парные комбинации
        if max_combinations >= 2:
            for combo in itertools.combinations(elements, 2):
                combinations.append(''.join(combo))
                combinations.append('_'.join(combo))
                combinations.append('-'.join(combo))
        
        return combinations
    
    def generate_all_variations(self) -> Set[str]:
        """Генерирует все возможные вариации паролей"""
        all_variations = set()
        
        print("Генерация вариаций паролей...")
        
        # 1. Добавляем все найденные пароли как есть
        for category, passwords in self.password_data.items():
            if category != "Мнемонические фразы":  # Исключаем длинные фразы
                for password in passwords:
                    all_variations.add(str(password))
        
        # 2. Генерируем вариации для базовых слов
        for base_word in self.base_words:
            # Базовые модификации
            modifications = self.add_common_modifications(base_word)
            all_variations.update(modifications)
            
            # Вариации регистра
            case_variations = self.generate_case_variations(base_word)
            for case_var in case_variations:
                all_variations.add(case_var)
                # Добавляем модификации для каждой вариации регистра
                all_variations.update(self.add_common_modifications(case_var))
            
            # Leet speak
            leet_variations = self.apply_leet_speak(base_word)
            for leet_var in leet_variations:
                all_variations.add(leet_var)
                all_variations.update(self.add_common_modifications(leet_var))
        
        # 3. Генерируем вариации для найденных паролей
        explicit_passwords = self.password_data.get("Явные пароли", [])
        for password in explicit_passwords[:10]:  # Ограничиваем количество для производительности
            # Вариации опечаток
            typo_variations = self.generate_typo_variations(password)
            all_variations.update(typo_variations)
            
            # Вариации регистра
            case_variations = self.generate_case_variations(password)
            all_variations.update(case_variations)
        
        # 4. Комбинации базовых элементов
        base_combinations = self.generate_combinations(self.base_words[:4], 2)
        all_variations.update(base_combinations)
        
        # 5. Добавляем числовые пароли с модификациями
        numeric_passwords = self.password_data.get("Числовые пароли/PIN", [])
        for num_pass in numeric_passwords:
            all_variations.add(str(num_pass))
            # Добавляем с базовыми словами
            for base in ['Michele', 'Super7Michele', 'bitcoin']:
                all_variations.add(base + str(num_pass))
                all_variations.add(str(num_pass) + base)
        
        return all_variations
    
    def prioritize_passwords(self, passwords: Set[str]) -> List[str]:
        """Приоритизирует пароли по вероятности"""
        password_list = list(passwords)
        
        # Критерии приоритизации
        def priority_score(password):
            score = 0
            
            # Найденные явные пароли имеют высший приоритет
            if password in self.password_data.get("Явные пароли", []):
                score += 1000
            
            # Содержит "Super7Michele" - высокий приоритет
            if "Super7Michele" in password:
                score += 500
            
            # Содержит "Michele" - средний приоритет
            if "Michele" in password:
                score += 200
            
            # Содержит важные даты
            if any(date in password for date in ['1980', '1987', '120885']):
                score += 100
            
            # Содержит специальные символы
            if any(char in password for char in '@#!$'):
                score += 50
            
            # Оптимальная длина (8-20 символов)
            if 8 <= len(password) <= 20:
                score += 30
            
            # Слишком короткие или длинные - штраф
            if len(password) < 6 or len(password) > 30:
                score -= 100
            
            return score
        
        # Сортируем по приоритету
        password_list.sort(key=priority_score, reverse=True)
        
        return password_list

def main():
    generator = PasswordVariationGenerator()
    
    print("=== ГЕНЕРАЦИЯ ВАРИАЦИЙ ПАРОЛЕЙ ===\n")
    
    # Генерируем все вариации
    all_variations = generator.generate_all_variations()
    
    print(f"Сгенерировано {len(all_variations)} уникальных вариаций паролей")
    
    # Приоритизируем
    prioritized_passwords = generator.prioritize_passwords(all_variations)
    
    # Сохраняем результаты
    results = {
        'total_variations': len(all_variations),
        'top_priority_passwords': prioritized_passwords[:100],  # Топ 100
        'all_passwords': prioritized_passwords
    }
    
    with open('/home/ubuntu/password_variations.json', 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    # Создаем простой текстовый файл для удобства
    with open('/home/ubuntu/password_list.txt', 'w', encoding='utf-8') as f:
        for i, password in enumerate(prioritized_passwords[:200], 1):
            f.write(f"{password}\n")
    
    print(f"\nТОП-20 НАИБОЛЕЕ ВЕРОЯТНЫХ ПАРОЛЕЙ:")
    for i, password in enumerate(prioritized_passwords[:20], 1):
        print(f"{i:2d}. {password}")
    
    print(f"\nРезультаты сохранены в:")
    print(f"- password_variations.json (полные данные)")
    print(f"- password_list.txt (топ-200 паролей)")

if __name__ == "__main__":
    main()

