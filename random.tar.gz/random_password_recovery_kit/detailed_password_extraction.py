#!/usr/bin/env python3
import re

def extract_all_potential_passwords():
    """Извлекает все потенциальные пароли из файла"""
    
    with open('/home/ubuntu/extracted_docx_content.txt', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Список всех найденных потенциальных паролей
    potential_passwords = []
    
    # Явные пароли из текста
    explicit_passwords = [
        "Solemaremontagna",
        "357.aAb",
        "Super7Michele1+",
        "Super7Michele71",
        "Super7Michele1980@#@!",
        "Super7Michele71°",
        "Super7Michele#!@",
        "Super7Michele71@",
        "Super7Michele#@!",
        "Super7Michele@",
        "Super7Michele!#@!",
        "Super7Michele@",
        "Super7Michele@7",
        "Super7Michele$#@!",
        "Super7Michele#@!#$",
        "Super7Michele$#@!",
        "Gi.Super7Michele#@#$",
        "DGTX1886",
        "Super7Michele$#@!",
        "HIUH7G6Gyh8H@SSFS",
        "micheletitanus2232#",
        "IOMicheleTA1980#@!",
        "KuMichelecoin1987#@!",
        "9305f",
        "USDMicheleX1980@#!",
        "mypasswordisLena2817!",
        "Coinbase1980#@!",
        "Bitfinex1980#@!",
        "BitMichele1234##@!",
        "MeMicheleGA1980#@!"
    ]
    
    # Числовые пароли и PIN-коды
    numeric_passwords = [
        "52139724",
        "55443399", 
        "55664477",
        "120885",
        "2817",
        "50993",
        "35028721",
        "16690093"
    ]
    
    # Мнемонические фразы
    mnemonic_phrases = [
        "balcony magnet chapter ketchup identify lady question radio walnut uncover jeans limit easily gallery bachelor credit chase talent",
        "balcony chase chapter ketchup identify lady question radio walnut uncover jeans limit easily gallery bachelor credit magnet talent",
        "aphid warped soggy arsenic omission essential aunt incur unveil habitat koala rafts woven refer hijack memoir twang king observant liquid roster renting wrist acumen aphid",
        "bounce style square timber silly evolve image manage mix movie cancel north"
    ]
    
    # Коды аутентификации
    auth_codes = [
        "YHF6QO4PRI7XM5B5",
        "33GNCTFYYUDGIM6KEPZZDNFO",
        "FHEHEI3RO35HHA4NQI6HRC32SJ4G4PQQ",
        "w5xujjn77eivmvup",
        "iyed6kzqoy2w6edo",
        "SDQL4PUALUHM3ZXY"
    ]
    
    # Имена пользователей и логины
    usernames = [
        "jpznvs1285",
        "supermichele",
        "jpznvs"
    ]
    
    # Возможные базовые пароли для вариаций
    base_passwords = [
        "Michele",
        "Barbara", 
        "Super7Michele",
        "Gardnelion96",
        "bitcoin",
        "wallet",
        "crypto",
        "ledger"
    ]
    
    # Важные даты
    dates = [
        "1980",
        "1987",
        "120885",
        "12.08.85",
        "10.02",
        "2817"
    ]
    
    all_passwords = {
        "Явные пароли": explicit_passwords,
        "Числовые пароли/PIN": numeric_passwords,
        "Мнемонические фразы": mnemonic_phrases,
        "Коды аутентификации": auth_codes,
        "Имена пользователей": usernames,
        "Базовые слова": base_passwords,
        "Важные даты": dates
    }
    
    return all_passwords

def print_password_categories():
    """Выводит все категории паролей"""
    passwords = extract_all_potential_passwords()
    
    print("=== ДЕТАЛЬНЫЙ АНАЛИЗ ВСЕХ ПОТЕНЦИАЛЬНЫХ ПАРОЛЕЙ ===\n")
    
    total_count = 0
    for category, password_list in passwords.items():
        print(f"{category.upper()}:")
        for i, password in enumerate(password_list, 1):
            print(f"  {i:2d}. {password}")
        print(f"  Всего в категории: {len(password_list)}\n")
        total_count += len(password_list)
    
    print(f"ОБЩЕЕ КОЛИЧЕСТВО ПОТЕНЦИАЛЬНЫХ ПАРОЛЕЙ: {total_count}")
    
    return passwords

def analyze_bitcoin_wallet_structure():
    """Анализирует структуру Bitcoin кошелька"""
    print("\n=== АНАЛИЗ СТРУКТУРЫ BITCOIN КОШЕЛЬКА ===\n")
    
    # Анализ HESHWALLET@BTC.txt
    with open('/home/ubuntu/upload/HESHWALLET@BTC.txt', 'r') as f:
        hash_content = f.read().strip()
    
    print("ФОРМАТ ХЕША ПАРОЛЯ:")
    print(f"Содержимое: {hash_content}")
    
    # Разбор формата хеша
    if hash_content.startswith('$bitcoin$'):
        parts = hash_content.split('$')
        print(f"\nРазбор хеша:")
        print(f"Тип: {parts[1]}")
        print(f"Параметры: {parts[2:]}")
        print("Это хеш пароля Bitcoin Core кошелька для использования с hashcat или john the ripper")
    
    # Анализ wallet_dump.txt
    print(f"\nИНФОРМАЦИЯ ИЗ ДАМПА КОШЕЛЬКА:")
    print("- Кошелек зашифрован (The wallet is encrypted)")
    print("- Найдены зашифрованные приватные ключи")
    print("- Адрес по умолчанию: 1NyAYbSvrx8T1YkwqnKQ6JZkTeKHcB4Les")
    
    # Дополнительные адреса из docx
    print(f"\nДОПОЛНИТЕЛЬНЫЕ АДРЕСА ИЗ ФАЙЛОВ:")
    addresses = [
        "bc1q40m68z5fpee4vzh3a27me7rs31uq51e5sqy8m3",
        "3N3aQhWLbhKh2zTgFYRmcJCeZMXdE2rwka",
        "3AW3soMHYWXpn37RwSM8CFbYWzcfg4uLEc"
    ]
    for addr in addresses:
        print(f"- {addr}")

if __name__ == "__main__":
    passwords = print_password_categories()
    analyze_bitcoin_wallet_structure()
    
    # Сохраняем детальные результаты
    import json
    with open('/home/ubuntu/detailed_passwords.json', 'w', encoding='utf-8') as f:
        json.dump(passwords, f, ensure_ascii=False, indent=2)
    
    print(f"\nДетальные результаты сохранены в detailed_passwords.json")

