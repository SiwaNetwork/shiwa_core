# 🚀 Быстрый старт - Восстановление пароля кошелька

## ⚠️ ВАЖНО: Меры безопасности
1. **Отключите интернет** перед началом работы
2. **Используйте КОПИЮ кошелька**, не оригинал
3. **Создайте резервные копии** всех файлов

## 🎯 ТОП-20 наиболее вероятных паролей

Попробуйте эти пароли в первую очередь:

```
1.  Super7Michele1980@#@!
2.  Super7Michele@7
3.  Super7Michele#@!
4.  Super7Michele!#@!
5.  Super7Michele@
6.  Super7Michele#@!#$
7.  Gi.Super7Michele#@#$
8.  Super7Michele#!@
9.  Super7Michele71@
10. Super7Michele$#@!
11. Super7Michele71°
12. Super7Michele71
13. Super7Michele1+
14. MeMicheleGA1980#@!
15. USDMicheleX1980@#!
16. IOMicheleTA1980#@!
17. KuMichelecoin1987#@!
18. BitMichele1234##@!
19. Bitfinex1980#@!
20. Coinbase1980#@!
```

## 🛠️ Быстрые команды

### Для hashcat (рекомендуется):
```bash
hashcat -m 11300 -a 0 HESHWALLET@BTC.txt password_list.txt --force
```

### Для John the Ripper:
```bash
john --wordlist=password_list.txt --format=bitcoin HESHWALLET@BTC.txt
```

### Автоматический тест (если установлен Bitcoin Core):
```bash
chmod +x test_passwords.sh
./test_passwords.sh
```

## 📊 Статистика
- **Всего паролей найдено:** 65
- **Всего вариаций создано:** 3,006
- **Файлы для тестирования:** готовы
- **Время анализа:** завершен

## 📁 Файлы в комплекте
- `password_list.txt` - топ-200 паролей
- `recovery_instructions.md` - подробные инструкции
- `wallet_recovery_report.md` - полный отчет
- `test_passwords.sh` - скрипт автотестирования
- `detailed_passwords.json` - все найденные пароли

## 🔄 Что делать после успешного восстановления
1. Создайте резервную копию разблокированного кошелька
2. Экспортируйте приватные ключи
3. Создайте новый кошелек с новым паролем
4. Переведите средства в новый кошелек
5. Безопасно удалите старые файлы

---
**Удачи в восстановлении! 🍀**

