#!/usr/bin/env python3
"""
Инструменты для восстановления пароля Bitcoin кошелька
Автор: Manus AI
"""

import json
import subprocess
import os
import sys
from typing import List, Dict, Optional
import hashlib
import time

class WalletPasswordTester:
    def __init__(self, wallet_path: str, hash_file: str = None):
        self.wallet_path = wallet_path
        self.hash_file = hash_file
        self.tested_passwords = set()
        self.results_file = "password_test_results.json"
        
    def load_password_list(self, password_file: str) -> List[str]:
        """Загружает список паролей из файла"""
        try:
            with open(password_file, 'r', encoding='utf-8') as f:
                passwords = [line.strip() for line in f if line.strip()]
            return passwords
        except FileNotFoundError:
            print(f"Файл {password_file} не найден")
            return []
    
    def test_password_with_bitcoin_core(self, password: str) -> bool:
        """
        Тестирует пароль с Bitcoin Core (требует установленный bitcoin-cli)
        ВНИМАНИЕ: Используйте только на копии кошелька!
        """
        try:
            # Команда для разблокировки кошелька
            cmd = ['bitcoin-cli', 'walletpassphrase', password, '1']
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                # Сразу блокируем кошелек обратно
                subprocess.run(['bitcoin-cli', 'walletlock'], capture_output=True)
                return True
            return False
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return False
    
    def generate_hashcat_command(self, password_file: str) -> str:
        """Генерирует команду для hashcat"""
        if not self.hash_file:
            return "Файл с хешем не указан"
        
        command = f"""hashcat -m 11300 -a 0 {self.hash_file} {password_file} --force"""
        return command
    
    def generate_john_command(self, password_file: str) -> str:
        """Генерирует команду для John the Ripper"""
        if not self.hash_file:
            return "Файл с хешем не указан"
        
        command = f"""john --wordlist={password_file} --format=bitcoin {self.hash_file}"""
        return command
    
    def create_batch_test_script(self, password_file: str, output_file: str = "test_passwords.sh"):
        """Создает bash скрипт для пакетного тестирования паролей"""
        script_content = f"""#!/bin/bash
# Скрипт для тестирования паролей Bitcoin кошелька
# ВНИМАНИЕ: Используйте только на копии кошелька!

WALLET_PATH="{self.wallet_path}"
PASSWORD_FILE="{password_file}"
RESULTS_FILE="password_test_results.txt"

echo "Начинаем тестирование паролей..."
echo "Дата начала: $(date)" > $RESULTS_FILE

counter=0
while IFS= read -r password; do
    counter=$((counter + 1))
    echo "Тестируем пароль #$counter: $password"
    
    # Попытка разблокировки кошелька
    if bitcoin-cli walletpassphrase "$password" 1 2>/dev/null; then
        echo "УСПЕХ! Найден правильный пароль: $password" | tee -a $RESULTS_FILE
        bitcoin-cli walletlock
        break
    else
        echo "Пароль неверный: $password" >> $RESULTS_FILE
    fi
    
    # Небольшая пауза между попытками
    sleep 0.1
done < "$PASSWORD_FILE"

echo "Тестирование завершено: $(date)" >> $RESULTS_FILE
echo "Проверено паролей: $counter"
"""
        
        with open(output_file, 'w') as f:
            f.write(script_content)
        
        # Делаем скрипт исполняемым
        os.chmod(output_file, 0o755)
        
        return output_file

class WalletSecurityAnalyzer:
    def __init__(self):
        self.security_recommendations = []
    
    def analyze_wallet_security(self, wallet_info: Dict) -> Dict:
        """Анализирует безопасность кошелька"""
        analysis = {
            'encryption_status': 'encrypted' if 'encrypted' in str(wallet_info).lower() else 'unknown',
            'key_count': 0,
            'address_count': 0,
            'recommendations': []
        }
        
        # Подсчитываем ключи и адреса
        if isinstance(wallet_info, dict):
            if 'keys' in wallet_info:
                analysis['key_count'] = len(wallet_info['keys'])
            if 'addresses' in wallet_info:
                analysis['address_count'] = len(wallet_info['addresses'])
        
        # Рекомендации по безопасности
        recommendations = [
            "Всегда работайте с копией кошелька, а не с оригиналом",
            "Используйте автономный компьютер для восстановления пароля",
            "Создайте резервную копию кошелька перед началом работы",
            "После восстановления пароля создайте новый кошелек с новым паролем",
            "Переведите средства в новый кошелек как можно скорее",
            "Используйте аппаратный кошелек для долгосрочного хранения"
        ]
        
        analysis['recommendations'] = recommendations
        return analysis

def create_recovery_instructions():
    """Создает подробные инструкции по восстановлению пароля"""
    instructions = """
# ИНСТРУКЦИИ ПО ВОССТАНОВЛЕНИЮ ПАРОЛЯ BITCOIN КОШЕЛЬКА

## ВАЖНЫЕ ПРЕДУПРЕЖДЕНИЯ ПО БЕЗОПАСНОСТИ

⚠️ **КРИТИЧЕСКИ ВАЖНО**: Никогда не работайте с оригинальным файлом кошелька! Всегда используйте копию.

⚠️ **БЕЗОПАСНОСТЬ**: Выполняйте восстановление на автономном компьютере, отключенном от интернета.

⚠️ **РЕЗЕРВНОЕ КОПИРОВАНИЕ**: Создайте несколько копий кошелька перед началом работы.

## МЕТОДЫ ВОССТАНОВЛЕНИЯ

### Метод 1: Использование hashcat (Рекомендуется)

1. Установите hashcat:
   ```bash
   # Ubuntu/Debian
   sudo apt install hashcat
   
   # или скачайте с официального сайта
   # https://hashcat.net/hashcat/
   ```

2. Подготовьте файл с хешем пароля (уже есть: HESHWALLET@BTC.txt)

3. Запустите hashcat с нашим списком паролей:
   ```bash
   hashcat -m 11300 -a 0 HESHWALLET@BTC.txt password_list.txt --force
   ```

### Метод 2: Использование John the Ripper

1. Установите John the Ripper:
   ```bash
   sudo apt install john
   ```

2. Запустите с нашим списком паролей:
   ```bash
   john --wordlist=password_list.txt --format=bitcoin HESHWALLET@BTC.txt
   ```

### Метод 3: Прямое тестирование с Bitcoin Core

1. Установите Bitcoin Core
2. Используйте наш bash-скрипт для автоматического тестирования
3. Запустите: `./test_passwords.sh`

## ПОРЯДОК ТЕСТИРОВАНИЯ ПАРОЛЕЙ

Пароли уже отсортированы по приоритету. Начните с первых 20:

1. Super7Michele1980@#@!
2. Super7Michele@7
3. Super7Michele#@!
4. Super7Michele!#@!
5. Super7Michele@
... и так далее

## ПОСЛЕ УСПЕШНОГО ВОССТАНОВЛЕНИЯ

1. **Немедленно создайте резервную копию** разблокированного кошелька
2. **Экспортируйте приватные ключи** в безопасное место
3. **Создайте новый кошелек** с новым, надежным паролем
4. **Переведите все средства** в новый кошелек
5. **Безопасно удалите** старые файлы кошелька

## ДОПОЛНИТЕЛЬНЫЕ ИНСТРУМЕНТЫ

### Создание собственного словаря паролей

Если стандартный список не сработает, можно создать дополнительные вариации:

```python
# Запустите наш генератор с дополнительными параметрами
python3 password_generator.py --extended
```

### Мониторинг прогресса

Используйте команды для отслеживания прогресса:

```bash
# Для hashcat
hashcat --status

# Для john
john --show HESHWALLET@BTC.txt
```

## ТЕХНИЧЕСКАЯ ИНФОРМАЦИЯ

- **Тип хеша**: Bitcoin Core wallet (hashcat mode 11300)
- **Алгоритм**: PBKDF2-HMAC-SHA512
- **Итерации**: 65866 (из анализа хеша)
- **Размер соли**: 16 байт

## КОНТАКТЫ ДЛЯ ПОДДЕРЖКИ

Если у вас возникли вопросы или проблемы, обратитесь к сообществу:
- Bitcoin Stack Exchange
- Reddit: r/Bitcoin, r/bitcoinbeginners
- Telegram: Bitcoin Recovery группы

## ПРАВОВАЯ ИНФОРМАЦИЯ

Эти инструменты предназначены только для восстановления доступа к вашим собственным кошелькам. 
Использование для взлома чужих кошельков является незаконным.
"""
    
    return instructions

def main():
    print("=== СОЗДАНИЕ ИНСТРУМЕНТОВ ДЛЯ ВОССТАНОВЛЕНИЯ ПАРОЛЯ ===\n")
    
    # Создаем основные инструменты
    tester = WalletPasswordTester(
        wallet_path="/home/ubuntu/upload/wallet.dat",
        hash_file="/home/ubuntu/upload/HESHWALLET@BTC.txt"
    )
    
    # Создаем bash скрипт для тестирования
    script_file = tester.create_batch_test_script("password_list.txt")
    print(f"Создан bash скрипт: {script_file}")
    
    # Генерируем команды для hashcat и john
    hashcat_cmd = tester.generate_hashcat_command("password_list.txt")
    john_cmd = tester.generate_john_command("password_list.txt")
    
    print(f"Команда для hashcat:")
    print(f"  {hashcat_cmd}")
    print(f"Команда для John the Ripper:")
    print(f"  {john_cmd}")
    
    # Создаем инструкции
    instructions = create_recovery_instructions()
    with open('/home/ubuntu/recovery_instructions.md', 'w', encoding='utf-8') as f:
        f.write(instructions)
    
    print(f"\\nСозданы файлы:")
    print(f"- {script_file} (bash скрипт для тестирования)")
    print(f"- recovery_instructions.md (подробные инструкции)")
    
    # Анализируем безопасность
    analyzer = WalletSecurityAnalyzer()
    
    # Загружаем информацию о кошельке
    try:
        with open('/home/ubuntu/password_analysis_results.json', 'r') as f:
            wallet_info = json.load(f)
        
        security_analysis = analyzer.analyze_wallet_security(wallet_info)
        
        print(f"\\n=== АНАЛИЗ БЕЗОПАСНОСТИ ===")
        print(f"Статус шифрования: {security_analysis['encryption_status']}")
        print(f"\\nРекомендации по безопасности:")
        for i, rec in enumerate(security_analysis['recommendations'], 1):
            print(f"{i}. {rec}")
            
    except FileNotFoundError:
        print("Файл анализа кошелька не найден")

if __name__ == "__main__":
    main()

